package persistencia;

import java.util.ArrayList;
import negocio.Veiculo;

public class ControlaVeiculo {
    
    private ArrayList<Veiculo> veiculos = new ArrayList<> ();
    
    public boolean Salvar(Veiculo v){
        if(v != null){
            veiculos.add(v);
            return true;
        }else{
            return false;
        }
    }
    
    public ArrayList<Veiculo> retornarTodos (){
        return veiculos;
    }
    
    public void Remover(String x){
        for (int i = 0; i < veiculos.size(); i++) {
            Veiculo v = veiculos.get(i);
            
            if (v.getNome().equals(x)) {
                veiculos.remove(v);
            }
            
            break;
        }
    }
    
}
