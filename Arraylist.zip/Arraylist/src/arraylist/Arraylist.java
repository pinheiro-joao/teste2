package arraylist;

import apresentacao.Principal;

public class Arraylist {
    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.setVisible(true);
        
    }
    
}
