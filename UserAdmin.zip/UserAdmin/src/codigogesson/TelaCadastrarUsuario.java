package codigogesson;

import codigogesson.Usuario;
import codigogesson.TelaInicio;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaCadastrarUsuario extends javax.swing.JFrame {

    ArrayList<Usuario> usuarios = new ArrayList<>();

    public TelaCadastrarUsuario() {
        initComponents();
        btAlterar.setEnabled(false);
        btExcluir.setEnabled(false);
        setExtendedState(MAXIMIZED_BOTH);
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbNome = new javax.swing.JLabel();
        tfNome = new javax.swing.JTextField();
        lbEmail = new javax.swing.JLabel();
        tfEmail = new javax.swing.JTextField();
        lbTelefone = new javax.swing.JLabel();
        tfTelefone = new javax.swing.JTextField();
        lbSenha = new javax.swing.JLabel();
        pfSenha = new javax.swing.JPasswordField();
        lbSenhaRepetida = new javax.swing.JLabel();
        pfSenhaRepetida = new javax.swing.JPasswordField();
        btCadastrar = new javax.swing.JButton();
        btAlterar = new javax.swing.JButton();
        btExcluir = new javax.swing.JButton();
        btLimpar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbUsuario = new javax.swing.JTable();
        btVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastrar Usuários");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        lbNome.setText("Nome:");

        lbEmail.setText("Email:");

        lbTelefone.setText("Telefone:");

        lbSenha.setText("Senha:");

        lbSenhaRepetida.setText("Senha Repetida:");

        pfSenhaRepetida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pfSenhaRepetidaActionPerformed(evt);
            }
        });

        btCadastrar.setText("Cadastrar");
        btCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCadastrarActionPerformed(evt);
            }
        });

        btAlterar.setText("Alterar");
        btAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAlterarActionPerformed(evt);
            }
        });

        btExcluir.setText("Excluir");
        btExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btExcluirActionPerformed(evt);
            }
        });

        btLimpar.setText("Limpar");
        btLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLimparActionPerformed(evt);
            }
        });

        tbUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Email", "Telefone"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbUsuarioMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tbUsuarioMouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(tbUsuario);

        btVoltar.setText("Voltar");
        btVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btVoltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 692, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbTelefone)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfTelefone))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbEmail)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfEmail))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfNome))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbSenha)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pfSenha))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btCadastrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btVoltar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbSenhaRepetida)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pfSenhaRepetida)))
                .addContainerGap(9, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbNome)
                    .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbEmail)
                    .addComponent(tfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbTelefone)
                    .addComponent(tfTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbSenha)
                    .addComponent(pfSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbSenhaRepetida)
                    .addComponent(pfSenhaRepetida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btVoltar)
                        .addComponent(btLimpar))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btCadastrar)
                        .addComponent(btAlterar)
                        .addComponent(btExcluir)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                .addGap(16, 16, 16))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pfSenhaRepetidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pfSenhaRepetidaActionPerformed

    }//GEN-LAST:event_pfSenhaRepetidaActionPerformed

    
    private void btCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCadastrarActionPerformed
        
        if(tfNome.getText().equals("") || tfEmail.getText().equals("") || tfTelefone.getText().equals("") || pfSenha.getText().equals("") || pfSenhaRepetida.getText().equals("")){ // testa se tem campo vazio
            JOptionPane.showMessageDialog(rootPane, "Preencha todos os campos!");
        }else{
            
            if(pfSenha.getText().equals(pfSenhaRepetida.getText())){
                Usuario usuario = new Usuario(tfNome.getText(), tfEmail.getText(), tfTelefone.getText(), pfSenha.getText());
                
                usuarios.add(usuario); // adiciona na arraylist 
                limparTela();
                
                JOptionPane.showMessageDialog(rootPane, "Usuario Cadastrado!");
                try {
                    atualizarTabela();
                } catch (IOException ex) {
                    Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
                JOptionPane.showMessageDialog(rootPane, "Senhas nao sao iguais!");
            }
            
            
        }
        
       
    }//GEN-LAST:event_btCadastrarActionPerformed

    private void btLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLimparActionPerformed
        limparTela();
    }//GEN-LAST:event_btLimparActionPerformed

    private void tbUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbUsuarioMouseClicked
        int linhaSelecionada = tbUsuario.getSelectedRow();
        
        if(linhaSelecionada >= 0){
            btExcluir.setEnabled(true);
            btAlterar.setEnabled(true);
            btCadastrar.setEnabled(false);
            
            // Pega os dados do array list de acordo com o usuário selecionado
            String nome = usuarios.get(linhaSelecionada).getNome();
            String email = usuarios.get(linhaSelecionada).getEmail();
            String telefone = usuarios.get(linhaSelecionada).getTelefone();
            String senha = usuarios.get(linhaSelecionada).getSenha();
            
            tfNome.setText(nome);
            tfEmail.setText(email);
            tfTelefone.setText(telefone);
            pfSenha.setText(senha);
            pfSenhaRepetida.setText(senha);
        }
    }//GEN-LAST:event_tbUsuarioMouseClicked

    private void btExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btExcluirActionPerformed
        int linhaSelecionada = tbUsuario.getSelectedRow();
        
        
        
        for(int i = 0; i<usuarios.size(); i++){
            if(i == linhaSelecionada){
                usuarios.remove(i);
                try {
                    atualizarTabela();
                } catch (IOException ex) {
                    Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        btExcluir.setEnabled(false);
        btAlterar.setEnabled(false);
        btCadastrar.setEnabled(true);
        
        
        limparTela();
        
        JOptionPane.showMessageDialog(null, "Usuário excluído com sucesso!");
    }//GEN-LAST:event_btExcluirActionPerformed

    private void tbUsuarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbUsuarioMouseExited

    }//GEN-LAST:event_tbUsuarioMouseExited

    private void btAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAlterarActionPerformed
        int linhaSelecionada = tbUsuario.getSelectedRow();
        
        if(linhaSelecionada >= 0){
            if(tfNome.getText().equals("") || tfEmail.getText().equals("") || tfTelefone.getText().equals("") || pfSenha.getText().equals("") || pfSenhaRepetida.getText().equals("")){ // testa se tem campo vazio
            JOptionPane.showMessageDialog(rootPane, "Preencha todos os campos!");
            }else{
            
                if(pfSenha.getText().equals(pfSenhaRepetida.getText())){
                    Usuario usuario = new Usuario(tfNome.getText(), tfEmail.getText(), tfTelefone.getText(), pfSenha.getText());
                
                    usuarios.get(linhaSelecionada).setNome(tfNome.getText());
                    usuarios.get(linhaSelecionada).setEmail(tfEmail.getText());
                    usuarios.get(linhaSelecionada).setTelefone(tfTelefone.getText());
                    usuarios.get(linhaSelecionada).setSenha(pfSenha.getText());
                    
                    limparTela();
                
                    JOptionPane.showMessageDialog(rootPane, "Usuario Atualizado!");
                    try {
                        atualizarTabela();
                    } catch (IOException ex) {
                        Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    btAlterar.setEnabled(false);
                    btExcluir.setEnabled(false);
                    btCadastrar.setEnabled(true);
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Senhas nao sao iguais!");
                }
            
            
            }
        }
    }//GEN-LAST:event_btAlterarActionPerformed

    private void btVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btVoltarActionPerformed
        this.setVisible(false);
        TelaInicio telaInicio = new TelaInicio();
        telaInicio.setVisible(true);
    }//GEN-LAST:event_btVoltarActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            usuarios = (ArrayList<Usuario>) Gravador.ler("usuarios.dat");
        } catch (IOException ex) {
            Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            atualizarTabela();
        } catch (IOException ex) {
            Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowOpened

    public void limparTela(){
        tfNome.setText("");
        tfEmail.setText("");
        tfTelefone.setText("");
        pfSenha.setText("");
        pfSenhaRepetida.setText("");
    }
    
    public void atualizarTabela() throws IOException{
        //Salva o arryList de usuarios no arquivos || "usuarios.dat" é o nome do arquivo
        Gravador.gravar("usuarios.dat", usuarios);
        
        DefaultTableModel modelo = (DefaultTableModel) tbUsuario.getModel();
        
        modelo.setNumRows(0);
        
        Object linha[] = new Object[3]; // cria um modelo de linha da tabela com 3 colunas
        
        for(int i = 0; i < usuarios.size(); i++){
            linha[0] = usuarios.get(i).getNome(); // pega o nome do usuario da lista da posicao i
            linha[1] = usuarios.get(i).getEmail();
            linha[2] = usuarios.get(i).getTelefone();
            modelo.addRow(linha); // adiciona a linha na tabela
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastrarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastrarUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAlterar;
    private javax.swing.JButton btCadastrar;
    private javax.swing.JButton btExcluir;
    private javax.swing.JButton btLimpar;
    private javax.swing.JButton btVoltar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbEmail;
    private javax.swing.JLabel lbNome;
    private javax.swing.JLabel lbSenha;
    private javax.swing.JLabel lbSenhaRepetida;
    private javax.swing.JLabel lbTelefone;
    private javax.swing.JPasswordField pfSenha;
    private javax.swing.JPasswordField pfSenhaRepetida;
    private javax.swing.JTable tbUsuario;
    private javax.swing.JTextField tfEmail;
    private javax.swing.JTextField tfNome;
    private javax.swing.JTextField tfTelefone;
    // End of variables declaration//GEN-END:variables
}
